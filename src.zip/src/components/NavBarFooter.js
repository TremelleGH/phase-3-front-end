import React from 'react'

function NavBarFooter() {
  return (
    <div>
        
    </div>
  )
}

export default NavBarFooter